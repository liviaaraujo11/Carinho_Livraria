document.addEventListener("DOMContentLoaded", function() {
    const cartItemsDiv = document.getElementById('cart-items');
    const totalPriceSpan = document.getElementById('total-price');
    let cartItems = JSON.parse(localStorage.getItem('cart')) || [];

    if (cartItems.length === 0) {
        cartItemsDiv.innerHTML = "<p>O carrinho está vazio.</p>";
        document.getElementById('cart-summary').style.display = 'none'; // Esconde o resumo do carrinho
    } else {
        let cartHTML = '';
        let total = 0;

        cartItems.forEach(item => {
            const price = parseFloat(item.price.replace('R$', '').replace(',', '.')); // Converte o preço para número
            const itemTotal = price * item.quantity; // Calcula o total do item
            total += itemTotal; // Acumula o preço total

            cartHTML += `
                <div class="cart-item">
                    <img src="${item.image}" alt="${item.title}" class="cart-item-img">
                    <div>
                        <h4>${item.title}</h4>
                        <p>Autor: ${item.author}</p>
                        <p>Preço Unitário: ${item.price}</p>
                        <p>Quantidade: 
                            <input type="number" value="${item.quantity}" min="1" onchange="updateQuantity(${item.id}, this.value)">
                        </p>
                        <p>Total: R$ ${itemTotal.toFixed(2).replace('.', ',')}</p>
                    </div>
                    <button class="btn btn-danger" onclick="removeFromCart(${item.id})">Remover</button>
                </div>
            `;
        });

        // Exibe os itens do carrinho
        cartItemsDiv.innerHTML = cartHTML;

        // Exibe o total da compra
        totalPriceSpan.textContent = `R$ ${total.toFixed(2).replace('.', ',')}`;
    }
});

// Função para remover um item do carrinho
function removeFromCart(productId) {
    let cartItems = JSON.parse(localStorage.getItem('cart')) || [];

    // Remove o item correspondente
    cartItems = cartItems.filter(item => item.id !== productId);

    // Atualiza o localStorage
    localStorage.setItem('cart', JSON.stringify(cartItems));

    // Recarrega a página para refletir a mudança
    location.reload();
}

// Função para atualizar a quantidade de um item
function updateQuantity(productId, newQuantity) {
    let cartItems = JSON.parse(localStorage.getItem('cart')) || [];
    newQuantity = parseInt(newQuantity);

    // Atualiza a quantidade do item
    cartItems = cartItems.map(item => {
        if (item.id === productId) {
            item.quantity = newQuantity;
        }
        return item;
    });

    // Atualiza o localStorage
    localStorage.setItem('cart', JSON.stringify(cartItems));

    // Recarrega a página para refletir a mudança
    location.reload();
}

// Função para finalizar a compra
document.getElementById('checkout-btn').addEventListener('click', function() {
    alert('Compra finalizada com sucesso!');
    // Limpa o carrinho após finalizar a compra
    localStorage.removeItem('cart');
    // Recarrega a página para mostrar que o carrinho está vazio
    location.reload();
});

