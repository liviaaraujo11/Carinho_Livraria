document.addEventListener("DOMContentLoaded", function () {
  fetch("http://localhost:3000/products")
    .then((response) => response.json())
    .then((products) => {
      const productList = document.getElementById("product-list");
      let productCards = "";

      products.forEach((product) => {
        productCards += `
          <div class="col-md-3 align-items-center justify-content-center">
            <div class="card product-card">
              <a href="${product.buyLink}">
                <img src="${product.image}" class="card-img-top product-img product-img-margin" alt="${product.title}">
              </a>
              <div class="card-body">
                <h5 class="card-title">${product.title}</h5>
                <p class="card-text">${product.author}</p>
                <p class="card-text">${product.price}</p>
                <button class="btn btn-dark mt-2 btn-card" onclick="addToCart(${product.id})">Comprar</button>
                <a href="${product.buyLink}?id=${product.id}" class="btn btn-outline-secondary mt-2 btn-card">Ver Mais</a>
              </div>
            </div>
          </div>
        `;
      });

      productList.innerHTML = productCards;
    })
    .catch((error) => console.error("Erro ao carregar os produtos:", error));
});

// Função para adicionar ao carrinho

function addToCart(product) {
  let cartItems = JSON.parse(localStorage.getItem("cart")) || [];

  // Verifica se o item já está no carrinho
  const existingItem = cartItems.find((item) => item.id === product.id);
  if (existingItem) {
    // Se já existir, apenas aumenta a quantidade
    existingItem.quantity += 1;
  } else {
    // Se não existir, adiciona o item com quantidade 1
    product.quantity = 1;
    cartItems.push(product);
  }

  // Atualiza o localStorage
  localStorage.setItem("cart", JSON.stringify(cartItems));

  // Atualiza o contador de itens no carrinho, se existir
  updateCartCount();
}